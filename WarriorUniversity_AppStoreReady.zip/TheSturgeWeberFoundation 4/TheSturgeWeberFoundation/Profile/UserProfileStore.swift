import Foundation
import SwiftUI
import Security
import Combine
import CoreData

/// Manages user profile data (name, photo, preferences)
/// Uses UserDefaults for profile + Keychain for passcode security
/// Each account gets a unique userId to isolate CoreData records
final class UserProfileStore: ObservableObject {
    static let shared = UserProfileStore()

    // MARK: - Published Properties

    @Published var userName: String {
        didSet { UserDefaults.standard.set(userName, forKey: Keys.userName) }
    }
    @Published var userEmail: String {
        didSet { UserDefaults.standard.set(userEmail, forKey: Keys.userEmail) }
    }
    @Published var profileImageData: Data? {
        didSet { UserDefaults.standard.set(profileImageData, forKey: Keys.profileImage) }
    }
    @Published var notificationsEnabled: Bool {
        didSet { UserDefaults.standard.set(notificationsEnabled, forKey: Keys.notificationsEnabled) }
    }
    @Published var reminderHoursBefore: Int {
        didSet { UserDefaults.standard.set(reminderHoursBefore, forKey: Keys.reminderHours) }
    }
    @Published var isLoggedIn: Bool {
        didSet { UserDefaults.standard.set(isLoggedIn, forKey: Keys.isLoggedIn) }
    }

    // MARK: - User ID (unique per account, used to tag all CoreData records)

    var userId: String {
        UserDefaults.standard.string(forKey: Keys.userId) ?? "default"
    }

    // MARK: - Keys

    private enum Keys {
        static let userName = "wu.user.name"
        static let userEmail = "wu.user.email"
        static let profileImage = "wu.user.profileImage"
        static let notificationsEnabled = "wu.user.notificationsEnabled"
        static let reminderHours = "wu.user.reminderHours"
        static let isLoggedIn = "wu.user.isLoggedIn"
        static let hasAccount = "wu.user.hasAccount"
        static let userId = "wu.user.userId"
        static let keychainService = "org.sturgeweber.warrioruniversity"
        static let keychainPasscode = "wu.passcode"
    }

    // MARK: - Init

    private init() {
        let ud = UserDefaults.standard
        self.userName = ud.string(forKey: Keys.userName) ?? ""
        self.userEmail = ud.string(forKey: Keys.userEmail) ?? ""
        self.profileImageData = ud.data(forKey: Keys.profileImage)
        self.notificationsEnabled = ud.bool(forKey: Keys.notificationsEnabled)
        self.reminderHoursBefore = ud.object(forKey: Keys.reminderHours) as? Int ?? 24
        self.isLoggedIn = ud.bool(forKey: Keys.isLoggedIn)
    }

    // MARK: - Account Management

    var hasAccount: Bool {
        UserDefaults.standard.bool(forKey: Keys.hasAccount)
    }

    /// Create a new account with name + passcode
    func createAccount(name: String, email: String, passcode: String) {
        // Generate a unique userId for this account
        let newUserId = UUID().uuidString
        UserDefaults.standard.set(newUserId, forKey: Keys.userId)
        
        userName = name
        userEmail = email
        savePasscodeToKeychain(passcode)
        UserDefaults.standard.set(true, forKey: Keys.hasAccount)
        isLoggedIn = true
    }

    /// Validate passcode for login
    func validatePasscode(_ passcode: String) -> Bool {
        guard let stored = loadPasscodeFromKeychain() else {
            // Fallback: check old UserDefaults passcode (migration)
            if let oldPasscode = UserDefaults.standard.string(forKey: "wu.passcode") {
                if oldPasscode == passcode {
                    savePasscodeToKeychain(passcode)
                    UserDefaults.standard.removeObject(forKey: "wu.passcode")
                    return true
                }
            }
            return false
        }
        return stored == passcode
    }

    /// Change passcode
    func changePasscode(oldPasscode: String, newPasscode: String) -> Bool {
        guard validatePasscode(oldPasscode) else { return false }
        savePasscodeToKeychain(newPasscode)
        return true
    }

    func logout() {
        isLoggedIn = false
    }

    func deleteAccount() {
        // Delete all CoreData records for this user
        deleteAllUserData()
        
        userName = ""
        userEmail = ""
        profileImageData = nil
        notificationsEnabled = false
        reminderHoursBefore = 24
        isLoggedIn = false
        deletePasscodeFromKeychain()
        UserDefaults.standard.removeObject(forKey: Keys.hasAccount)
        UserDefaults.standard.removeObject(forKey: Keys.userId)
        UserDefaults.standard.removeObject(forKey: "wu.passcode")
        
        // Delete timer events (stored as JSON files, not CoreData)
        TimerStore.shared.deleteAllForCurrentUser()
        
        // Cancel all notifications
        NotificationManager.shared.cancelAll()
    }
    
    /// Delete all CoreData records belonging to this user
    private func deleteAllUserData() {
        let currentUserId = userId
        let container = NSPersistentContainer(name: "TheSturgeWeberFoundation")
        container.loadPersistentStores { _, _ in }
        let context = container.viewContext
        
        let entities = ["EventEntity", "DoctorEntity", "MedsEquipmentEntity", "NoteEntity"]
        for entityName in entities {
            let req = NSFetchRequest<NSManagedObject>(entityName: entityName)
            req.predicate = NSPredicate(format: "userId == %@", currentUserId)
            if let objects = try? context.fetch(req) {
                for obj in objects {
                    context.delete(obj)
                }
            }
        }
        try? context.save()
    }

    // MARK: - Profile Image

    var profileImage: UIImage? {
        guard let data = profileImageData else { return nil }
        return UIImage(data: data)
    }

    func setProfileImage(_ image: UIImage?) {
        profileImageData = image?.jpegData(compressionQuality: 0.7)
    }

    // MARK: - Keychain Helpers

    private func savePasscodeToKeychain(_ passcode: String) {
        let data = passcode.data(using: .utf8)!
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: Keys.keychainService,
            kSecAttrAccount as String: Keys.keychainPasscode,
        ]
        SecItemDelete(query as CFDictionary)
        var newQuery = query
        newQuery[kSecValueData as String] = data
        SecItemAdd(newQuery as CFDictionary, nil)
    }

    private func loadPasscodeFromKeychain() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: Keys.keychainService,
            kSecAttrAccount as String: Keys.keychainPasscode,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func deletePasscodeFromKeychain() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: Keys.keychainService,
            kSecAttrAccount as String: Keys.keychainPasscode,
        ]
        SecItemDelete(query as CFDictionary)
    }
}
