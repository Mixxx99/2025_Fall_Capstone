import SwiftUI

@main
struct TheSturgeWeberFoundationApp: App {
    // Shared stores available app-wide
    @StateObject private var eventStore = EventStore.shared
    @StateObject private var timerStore = TimerStore.shared
    @StateObject private var profileStore = UserProfileStore.shared

    var body: some Scene {
        WindowGroup {
            RootRouter()
                .environmentObject(eventStore)
                .environmentObject(timerStore)
                .environmentObject(profileStore)
        }
    }
}

/// Navigation router: Welcome → Register/Login → Home
/// Supports: new users (register), returning users (login), logout
struct RootRouter: View {
    @EnvironmentObject private var profileStore: UserProfileStore

    enum Route: Hashable { case register, login, home }
    @State private var path: [Route] = []

    var body: some View {
        NavigationStack(path: $path) {
            startView
                .navigationDestination(for: Route.self) { route in
                    switch route {
                    case .register:
                        RegisterView {
                            DispatchQueue.main.async { path = [.home] }
                        }
                        .navigationBarBackButtonHidden()
                    case .login:
                        LoginView {
                            DispatchQueue.main.async { path = [.home] }
                        }
                        .navigationBarBackButtonHidden()
                    case .home:
                        HomeView()
                            .navigationBarBackButtonHidden()
                    }
                }
        }
        .task {
            determineInitialRoute()
        }
        .onChange(of: profileStore.isLoggedIn) { _, loggedIn in
            if !loggedIn {
                // User logged out or deleted account — go back to welcome
                path = []
            }
        }
    }

    @ViewBuilder
    private var startView: some View {
        WelcomeView {
            if profileStore.hasAccount {
                path.append(.login)
            } else {
                path.append(.register)
            }
        }
    }

    private func determineInitialRoute() {
        if profileStore.hasAccount && profileStore.isLoggedIn {
            // Already logged in from last session
            path = [.home]
        } else if profileStore.hasAccount {
            // Has account but not logged in (app restart)
            path = [.login]
        }
        // Else: show welcome (no account)

        // Migration: if old passcode exists in UserDefaults but no account yet
        if !profileStore.hasAccount,
           let oldPasscode = UserDefaults.standard.string(forKey: "wu.passcode") {
            // Old user from Capstone 1 — migrate them
            profileStore.createAccount(name: "Warrior", email: "", passcode: oldPasscode)
            UserDefaults.standard.removeObject(forKey: "wu.passcode")
            path = [.home]
        }
    }
}
