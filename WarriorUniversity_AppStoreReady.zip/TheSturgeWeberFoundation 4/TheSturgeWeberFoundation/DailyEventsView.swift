import SwiftUI

struct DailyEventsView: View {
    @EnvironmentObject var store: EventStore
    @State private var selectedDate = Date()
    @State private var showAdd = false

    private var eventsForDay: [EventEntity] {
        store.events.filter { evt in
            guard let d = evt.date else { return false }
            return Calendar.current.isDate(d, inSameDayAs: selectedDate)
        }
    }

    var body: some View {
        ZStack {
            SWFAppBackground()

            VStack {
                DatePicker("", selection: $selectedDate, displayedComponents: [.date])
                    .datePickerStyle(.compact)
                    .labelsHidden()
                    .padding(.horizontal)

                if eventsForDay.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "calendar.badge.plus")
                            .font(.system(size: 40))
                            .foregroundStyle(.white.opacity(0.5))
                        Text("No events for this day")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.7))
                        Button("Add Event") { showAdd = true }
                            .font(.subheadline.bold())
                            .foregroundStyle(Color.swfGoldenYellow)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(eventsForDay) { event in
                            NavigationLink(destination: EventDetailView(event: event)) {
                                HStack(spacing: 12) {
                                    RoundedRectangle(cornerRadius: 2)
                                        .fill(Color(hex: (event.value(forKey: "tagColorHex") as? String) ?? "8C1E41") ?? Color.swfPortWine)
                                        .frame(width: 4, height: 44)

                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(event.title ?? "")
                                            .font(.headline)

                                        HStack(spacing: 8) {
                                            if let tag = event.value(forKey: "tagTitle") as? String, !tag.isEmpty {
                                                Text(tag)
                                                    .font(.caption.bold())
                                                    .padding(.horizontal, 8)
                                                    .padding(.vertical, 2)
                                                    .background(
                                                        (Color(hex: (event.value(forKey: "tagColorHex") as? String) ?? "8C1E41") ?? Color.swfPortWine).opacity(0.15)
                                                    )
                                                    .clipShape(Capsule())
                                            }

                                            Text(event.date?.formatted(date: .abbreviated, time: .shortened) ?? "")
                                                .font(.subheadline)
                                                .foregroundStyle(.secondary)
                                        }

                                        if let notes = event.notes, !notes.isEmpty {
                                            Text(notes)
                                                .font(.caption)
                                                .foregroundStyle(.secondary)
                                                .lineLimit(1)
                                        }
                                    }
                                }
                            }
                        }
                        .onDelete { indexSet in
                            for index in indexSet {
                                store.deleteEvent(eventsForDay[index])
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle(selectedDate.formatted(.dateTime.month().day().year()))
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { showAdd = true } label: { Image(systemName: "plus") }
                    .foregroundStyle(.white)
            }
        }
        .sheet(isPresented: $showAdd) {
            EditEventView(selectedDate: selectedDate)
                .environmentObject(store)
        }
    }
}
