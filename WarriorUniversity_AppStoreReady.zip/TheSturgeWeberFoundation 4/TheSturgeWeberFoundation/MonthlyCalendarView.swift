import SwiftUI

struct MonthlyCalendarView: View {
    @EnvironmentObject var store: EventStore
    @State private var currentMonth = Date()
    @State private var showAdd = false
    @State private var selectedDate = Date()
    @State private var showMonthPicker = false
    @State private var showDayEvents = false

    private let columns = Array(repeating: GridItem(.flexible()), count: 7)

    var body: some View {
        ZStack {
            SWFAppBackground()

            VStack {
                // Month header
                HStack {
                    Button { changeMonth(-1) } label: { Image(systemName: "chevron.left") }
                    Spacer()
                    Text(currentMonth.formatted(.dateTime.month().year()))
                        .font(.headline)
                        .foregroundStyle(.white)
                    Spacer()
                    Button { changeMonth(1) } label: { Image(systemName: "chevron.right") }
                }
                .padding(.horizontal)

                // Weekday labels
                HStack {
                    ForEach(Calendar.current.shortWeekdaySymbols, id: \.self) { day in
                        Text(day.prefix(2))
                            .font(.caption2)
                            .foregroundStyle(.white.opacity(0.8))
                            .frame(maxWidth: .infinity)
                    }
                }
                .padding(.horizontal, 6)

                // Calendar grid
                LazyVGrid(columns: columns, spacing: 8) {
                    ForEach(daysInMonth(currentMonth), id: \.self) { day in
                        Button {
                            selectedDate = day
                            if hasEvent(on: day) {
                                showDayEvents = true
                            } else {
                                showAdd = true
                            }
                        } label: {
                            VStack(spacing: 4) {
                                Text("\(Calendar.current.component(.day, from: day))")
                                    .font(.subheadline)
                                    .frame(width: 32, height: 32)
                                    .background(
                                        Calendar.current.isDateInToday(day)
                                            ? Color.swfGoldenYellow.opacity(0.3)
                                            : .clear
                                    )
                                    .clipShape(Circle())
                                    .foregroundStyle(.white)

                                // Color dots for events
                                HStack(spacing: 2) {
                                    ForEach(eventColors(on: day).prefix(3), id: \.self) { hex in
                                        Circle()
                                            .fill(Color(hex: hex) ?? Color.swfPortWine)
                                            .frame(width: 5, height: 5)
                                    }
                                }
                                .frame(height: 6)
                            }
                            .frame(height: 48)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
                
                Spacer()
            }
        }
        .sheet(isPresented: $showAdd) {
            EditEventView(selectedDate: selectedDate)
                .environmentObject(store)
        }
        .sheet(isPresented: $showDayEvents) {
            NavigationStack {
                DayEventsList(date: selectedDate)
                    .environmentObject(store)
            }
        }
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { showMonthPicker = true } label: {
                    Image(systemName: "calendar")
                }
                .accessibilityLabel("Pick Month and Year")
                .foregroundStyle(.white)
            }
        }
        .sheet(isPresented: $showMonthPicker) {
            MonthYearPickerSheet(initial: currentMonth) { picked in
                currentMonth = picked
            }
        }
    }

    private func changeMonth(_ delta: Int) {
        currentMonth = Calendar.current.date(byAdding: .month, value: delta, to: currentMonth) ?? currentMonth
    }

    private func hasEvent(on date: Date) -> Bool {
        store.events.contains { evt in
            guard let d = evt.date else { return false }
            return Calendar.current.isDate(d, inSameDayAs: date)
        }
    }

    /// Get unique tag colors for events on a given day
    private func eventColors(on date: Date) -> [String] {
        let dayEvents = store.events.filter { evt in
            guard let d = evt.date else { return false }
            return Calendar.current.isDate(d, inSameDayAs: date)
        }
        var seen = Set<String>()
        var colors: [String] = []
        for evt in dayEvents {
            let hex = (evt.value(forKey: "tagColorHex") as? String) ?? "8C1E41"
            if !seen.contains(hex) {
                seen.insert(hex)
                colors.append(hex)
            }
        }
        return colors
    }

    private func daysInMonth(_ date: Date) -> [Date] {
        let cal = Calendar.current
        guard let range = cal.range(of: .day, in: .month, for: date),
              let first = cal.date(from: cal.dateComponents([.year, .month], from: date)) else { return [] }
        return range.compactMap { cal.date(byAdding: .day, value: $0 - 1, to: first) }
    }
}

// MARK: - Day Events List (shown when tapping a day with events)

struct DayEventsList: View {
    let date: Date
    @EnvironmentObject var store: EventStore
    @Environment(\.dismiss) var dismiss
    @State private var showAdd = false

    private var eventsForDay: [EventEntity] {
        store.events.filter { evt in
            guard let d = evt.date else { return false }
            return Calendar.current.isDate(d, inSameDayAs: date)
        }
    }

    var body: some View {
        List {
            ForEach(eventsForDay) { event in
                HStack(spacing: 12) {
                    // Color bar
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color(hex: (event.value(forKey: "tagColorHex") as? String) ?? "8C1E41") ?? Color.swfPortWine)
                        .frame(width: 4, height: 44)

                    VStack(alignment: .leading, spacing: 4) {
                        Text(event.title ?? "")
                            .font(.headline)

                        HStack(spacing: 8) {
                            if let tag = event.value(forKey: "tagTitle") as? String, !tag.isEmpty {
                                Text(tag)
                                    .font(.caption.bold())
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 2)
                                    .background(
                                        (Color(hex: (event.value(forKey: "tagColorHex") as? String) ?? "8C1E41") ?? Color.swfPortWine).opacity(0.15)
                                    )
                                    .clipShape(Capsule())
                            }

                            Text(event.date?.formatted(date: .omitted, time: .shortened) ?? "")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }

                        if let notes = event.notes, !notes.isEmpty {
                            Text(notes)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(2)
                        }
                    }
                }
            }
            .onDelete { indexSet in
                for idx in indexSet {
                    store.deleteEvent(eventsForDay[idx])
                }
            }
        }
        .navigationTitle(date.formatted(.dateTime.weekday(.wide).month().day()))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button("Done") { dismiss() }
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button { showAdd = true } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(isPresented: $showAdd) {
            EditEventView(selectedDate: date)
                .environmentObject(store)
        }
    }
}
