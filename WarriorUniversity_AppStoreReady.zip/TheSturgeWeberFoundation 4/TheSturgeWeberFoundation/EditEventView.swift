import SwiftUI

/// Preset event categories with colors — requested by Julia
enum EventCategory: String, CaseIterable, Identifiable {
    case general = "General"
    case neurology = "Neurology"
    case dermatology = "Dermatology"
    case ophthalmology = "Ophthalmology"
    case medication = "Medication"
    case seizure = "Seizure"
    case therapy = "Therapy"
    case labWork = "Lab Work"
    case custom = "Custom"

    var id: String { rawValue }

    var colorHex: String {
        switch self {
        case .general:       return "8C1E41"  // Port Wine
        case .neurology:     return "4A90D9"  // Blue
        case .dermatology:   return "E67E22"  // Orange
        case .ophthalmology: return "27AE60"  // Green
        case .medication:    return "9B59B6"  // Purple
        case .seizure:       return "E74C3C"  // Red
        case .therapy:       return "1ABC9C"  // Teal
        case .labWork:       return "F39C12"  // Amber
        case .custom:        return "EBB533"  // SWF Gold
        }
    }

    var color: Color {
        Color(hex: colorHex) ?? .gray
    }

    var icon: String {
        switch self {
        case .general:       return "calendar"
        case .neurology:     return "brain.head.profile"
        case .dermatology:   return "hand.raised"
        case .ophthalmology: return "eye"
        case .medication:    return "pills"
        case .seizure:       return "bolt.heart"
        case .therapy:       return "figure.walk"
        case .labWork:       return "testtube.2"
        case .custom:        return "tag"
        }
    }
}

struct EditEventView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var store: EventStore

    @State private var title = ""
    @State private var notes = ""
    @State private var date: Date
    @State private var selectedCategory: EventCategory = .general
    @State private var customTagTitle: String = ""
    @State private var customTagColor: Color = Color(hex: "EBB533") ?? .yellow

    init(selectedDate: Date) {
        _date = State(initialValue: selectedDate)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Title
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Event Title")
                            .font(.caption.bold())
                            .foregroundStyle(.secondary)
                        TextField("e.g., Dr. Smith Appointment", text: $title)
                            .padding(12)
                            .background(Color(.secondarySystemGroupedBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }

                    // Date & Time
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Date & Time")
                            .font(.caption.bold())
                            .foregroundStyle(.secondary)
                        DatePicker("", selection: $date)
                            .labelsHidden()
                            .datePickerStyle(.compact)
                            .padding(12)
                            .background(Color(.secondarySystemGroupedBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }

                    // Category
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Category")
                            .font(.caption.bold())
                            .foregroundStyle(.secondary)

                        LazyVGrid(columns: [
                            GridItem(.flexible()),
                            GridItem(.flexible()),
                            GridItem(.flexible())
                        ], spacing: 8) {
                            ForEach(EventCategory.allCases) { cat in
                                Button {
                                    selectedCategory = cat
                                } label: {
                                    HStack(spacing: 6) {
                                        Image(systemName: cat.icon)
                                            .font(.caption)
                                        Text(cat.rawValue)
                                            .font(.caption.bold())
                                            .lineLimit(1)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .padding(.horizontal, 4)
                                    .background(
                                        selectedCategory == cat
                                            ? cat.color.opacity(0.2)
                                            : Color(.secondarySystemGroupedBackground)
                                    )
                                    .foregroundStyle(selectedCategory == cat ? cat.color : .primary)
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(selectedCategory == cat ? cat.color : .clear, lineWidth: 2)
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }

                    // Custom tag name if "Custom" selected
                    if selectedCategory == .custom {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Custom Tag Name")
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                            TextField("e.g., Physical Therapy", text: $customTagTitle)
                                .padding(12)
                                .background(Color(.secondarySystemGroupedBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            ColorPicker("Tag Color", selection: $customTagColor, supportsOpacity: false)
                                .padding(12)
                                .background(Color(.secondarySystemGroupedBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }

                    // Notes
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Notes (optional)")
                            .font(.caption.bold())
                            .foregroundStyle(.secondary)
                        TextField("Add any notes...", text: $notes, axis: .vertical)
                            .lineLimit(2...6)
                            .padding(12)
                            .background(Color(.secondarySystemGroupedBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }

                    // Save button
                    Button {
                        saveEvent()
                    } label: {
                        Text("Save Event")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(title.trimmingCharacters(in: .whitespaces).isEmpty ? Color.gray.opacity(0.3) : Color.swfPortWine)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                    }
                    .disabled(title.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("New Event")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }

    private func saveEvent() {
        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        let tagTitle: String?
        let tagColorHex: String?

        if selectedCategory == .custom {
            tagTitle = customTagTitle.isEmpty ? "Custom" : customTagTitle
            tagColorHex = customTagColor.hex6
        } else {
            tagTitle = selectedCategory.rawValue
            tagColorHex = selectedCategory.colorHex
        }

        store.addEvent(
            title: trimmed,
            date: date,
            notes: notes.isEmpty ? nil : notes,
            tagTitle: tagTitle,
            tagColorHex: tagColorHex
        )
        dismiss()
    }
}
