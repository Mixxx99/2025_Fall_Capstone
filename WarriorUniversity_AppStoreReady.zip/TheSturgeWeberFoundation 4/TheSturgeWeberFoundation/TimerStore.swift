import Foundation
import Combine

final class TimerStore: ObservableObject {
    @Published private(set) var events: [TimerEvent] = []
    static let shared = TimerStore()

    private let fm = FileManager.default
    private let dirURL: URL

    private var currentUserId: String {
        UserProfileStore.shared.userId
    }

    private init() {
        guard let appSupport = try? fm.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true) else {
            dirURL = URL(fileURLWithPath: NSTemporaryDirectory())
            return
        }
        let bundle = Bundle.main.bundleIdentifier ?? "org.sturgeweber.foundation"
        dirURL = appSupport.appendingPathComponent(bundle).appendingPathComponent("TimerEvents", isDirectory: true)
        try? fm.createDirectory(at: dirURL, withIntermediateDirectories: true)
        loadAll()
    }

    func loadAll() {
        var loaded: [TimerEvent] = []
        guard let urls = try? fm.contentsOfDirectory(at: dirURL, includingPropertiesForKeys: nil) else {
            self.events = []
            return
        }
        let uid = currentUserId
        for u in urls where u.pathExtension == "json" {
            if let data = try? Data(contentsOf: u),
               let event = try? JSONDecoder().decode(TimerEvent.self, from: data) {
                // Only show events for current user (or legacy events with default userId)
                if event.userId == uid || event.userId == "-1" {
                    loaded.append(event)
                }
            }
        }
        loaded.sort { $0.createdAt > $1.createdAt }
        self.events = loaded
    }

    func upsert(_ event: TimerEvent) {
        var tagged = event
        tagged.userId = currentUserId
        save(tagged)
        if let i = events.firstIndex(where: { $0.id == tagged.id }) {
            events[i] = tagged
        } else {
            events.insert(tagged, at: 0)
        }
    }

    func delete(_ event: TimerEvent) {
        try? fm.removeItem(at: fileURL(for: event.id))
        events.removeAll { $0.id == event.id }
    }
    
    /// Delete all timer events for current user (called on account deletion)
    func deleteAllForCurrentUser() {
        let uid = currentUserId
        guard let urls = try? fm.contentsOfDirectory(at: dirURL, includingPropertiesForKeys: nil) else { return }
        for u in urls where u.pathExtension == "json" {
            if let data = try? Data(contentsOf: u),
               let event = try? JSONDecoder().decode(TimerEvent.self, from: data),
               event.userId == uid {
                try? fm.removeItem(at: u)
            }
        }
        loadAll()
    }

    private func fileURL(for id: UUID) -> URL { dirURL.appendingPathComponent("\(id.uuidString).json") }

    private func save(_ event: TimerEvent) {
        do {
            let data = try JSONEncoder().encode(event)
            try data.write(to: fileURL(for: event.id), options: [.atomic, .completeFileProtection])
        } catch {
            print("TimerStore save error:", error)
        }
    }
}
