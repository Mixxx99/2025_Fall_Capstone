import SwiftUI

struct EventDetailView: View {
    let event: EventEntity

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Category tag
                if let tag = event.value(forKey: "tagTitle") as? String, !tag.isEmpty {
                    let hex = (event.value(forKey: "tagColorHex") as? String) ?? "8C1E41"
                    HStack(spacing: 6) {
                        Circle()
                            .fill(Color(hex: hex) ?? Color.swfPortWine)
                            .frame(width: 10, height: 10)
                        Text(tag)
                            .font(.subheadline.bold())
                            .foregroundStyle(Color(hex: hex) ?? Color.swfPortWine)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(
                        (Color(hex: hex) ?? Color.swfPortWine).opacity(0.1)
                    )
                    .clipShape(Capsule())
                }

                Text(event.title ?? "")
                    .font(.largeTitle).bold()

                Label(
                    event.date?.formatted(date: .long, time: .shortened) ?? "",
                    systemImage: "calendar"
                )
                .font(.headline)
                .foregroundStyle(.secondary)

                if let notes = event.notes, !notes.isEmpty {
                    Divider()
                    Text("Notes")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)
                    Text(notes)
                        .padding(.top, 2)
                }
                Spacer(minLength: 0)
            }
            .padding()
        }
        .navigationTitle("Event Details")
    }
}
